using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using System.Drawing.Drawing2D;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace BrynStuff.Items.Weapons.Melee
{
	public class DinoSword : ModItem
	{
		public override void SetStaticDefaults() 
		{
			DisplayName.SetDefault("Dinosaur Extinction Sword"); 
			Tooltip.SetDefault("Dedicated to Big Gay Dinosaur." +
				"\n \n \n \n \n \n h");
		}

		public override void SetDefaults() 
		{
			
            item.damage = 420;
			item.melee = true;
			item.width = 32;
			item.height = 32;
            item.useTime = 1;
			item.useAnimation = 10;
			item.useStyle = 3;
			item.knockBack = 2;
			item.value = 125000;
            item.rare = ItemRarityID.Purple;
			item.UseSound = SoundID.Item9;
			item.autoReuse = true;
			item.shoot = ProjectileID.NebulaBlaze2;
            item.shootSpeed = 32;
		}
        public override void AddRecipes() 
		{
			ModRecipe recipe = new ModRecipe(mod);
			recipe.SetResult(this);
			recipe.AddRecipe();
		}
		public override bool Shoot(Player player, ref Vector2 position, ref float speedX, ref float speedY, ref int type, ref int damage, ref float knockBack)
		{
			float numberProjectiles = 11; // 3, 4, or 5 shots
			position += Vector2.Normalize(new Vector2(speedX, speedY)) * 45f;
			position.X = Main.MouseWorld.X -55;
			position.Y = player.position.Y - 800;
			for (int i = 0; i < numberProjectiles; i++)
			{
			
				Projectile.NewProjectile(position.X, position.Y, 0, 20, type, 1500, knockBack, player.whoAmI);
				position.X += 10;
			}
			return false;
		}
	}
}